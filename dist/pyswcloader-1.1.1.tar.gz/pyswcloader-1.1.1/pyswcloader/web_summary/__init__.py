# from .web_summary_build import build_web_summary
from pyswcloader.web_summary.web_summary_build import build_web_summary
__all__ = [
    "build_web_summary"
]

